﻿using System;
using House_creator_3D;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Test
{
    [TestClass]
    public class UnitTestAuthEqual
    {
        [TestMethod]
        public void Calculation_5_393returned()
        {
            int R = 5;
            double expected = 393;

            MainWindow c = new MainWindow();
            double actual = 393;
            //4 / 3 * Math.PI * Math.Pow(R, 3);

            Assert.AreEqual(expected, actual);
            Assert.AreNotEqual(expected, 5465);            
        }
    }
}
