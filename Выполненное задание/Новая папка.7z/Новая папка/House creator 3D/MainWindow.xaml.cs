﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace House_creator_3D
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }      
        
        private void Radius_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void Volume_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        /// <summary>
        /// Метод при нажатие на кнопку выполняет вычисление 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Calculation_Click(object sender, RoutedEventArgs e)
        {
            double R = Convert.ToDouble(Radius.Text);
            double V;
            V = 4 / 3 * Math.PI * Math.Pow(R, 3);
            Volume.Text = V.ToString();
        }
        System.Text.RegularExpressions.Regex Numbers = new System.Text.RegularExpressions.Regex(@"[0-9]|[,]|[.]");//разрешения на ввод определённых символов 
        /// <summary>
        /// Проверка какие данные хочет ввести пользователь
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Radius_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            System.Text.RegularExpressions.Match match = Numbers.Match(e.Text);
            if (!match.Success)
            {
                e.Handled = true;
            }
        }
    }
}
